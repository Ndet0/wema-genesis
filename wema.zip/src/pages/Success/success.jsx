export default function Success() {
  return (
    <div style={{ padding: 40 }}>
      <h1>🎉 Thank You!</h1>
      <p>Your donation was processed successfully.</p>
    </div>
  );
}
