export default function Cancel() {
  return (
    <div style={{ padding: 40 }}>
      <h1>❌ Payment Cancelled</h1>
      <p>Your donation was not completed.</p>
    </div>
  );
}
